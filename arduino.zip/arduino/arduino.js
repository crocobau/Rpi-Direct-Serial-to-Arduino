﻿// Start of Arduino Receiver by Cristian Nicula June 2016 *******
//Please use this script in the header of HTML only!
//There is a frame loading Arduino response using url: 'http://127.0.0.1:1024/?AnyData=XYZ' which
//will return back 'AnyData=XYZ' inside ArduinoResponse element id defined in parent window
//Instead Page Refresh we will use Frame Reload which is faster
//Arduino will return http headers plus script inside html header: parent.postMessage('AnyData=XYZ')

var ArduinoRespVar="";
var ArduinoResp="";
window.addEventListener("message", function (event) {
    showErrorArduino("");
    StopHttp();

    ArduinoResp = event.data;

    if ((decodeURIComponent(event.data)).indexOf(ArduinoRespVar) > -1) {
        document.getElementById("ArduinoResponse").src = "arduino/ArduinoGreen.png";
        showSuccessArduino(ArduinoResp);
    }


    if ((decodeURIComponent(event.data)).indexOf(ArduinoRespVar) < 0)
        showErrorArduino(ArduinoResp);



});




function ArduinoSend(data, sec) { 
    showErrorArduino("");
    StopHttp();
    ArduinoResp = "";


    ArduinoRespVar = data;
    document.getElementById("ArduinoResponse").src = "arduino/ArduinoYellow.png";
    ArduinoFrame.src = "http://127.0.0.1:1024/?" + ArduinoRespVar;


    setTimeout(function () {


        if (ArduinoResp == "" && sec > 0) {
            StopHttp();

            document.getElementById("ArduinoResponse").src = "arduino/ArduinoRed.png";

            showErrorArduino("Ser2Web Timeout");
            ArduinoFrame.src = "http://127.0.0.1:1024/?" + ArduinoRespVar;

        }


    }, 1000 * sec);

}





function StopHttp() {
    ArduinoFrame.src = "";

}
// End of Arduino Receiver by Cristian Nicula June 2016 ****************************************




