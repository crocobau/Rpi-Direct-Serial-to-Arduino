This is the simple tutorial how a Raspberry Pi 2 is communicating with Arduino via USB.
(by Cristian Nicula - June 2016)


Prerequisite:
A.Raspberry Pi will use ser2net which make a bridge between ttyACM0 and port 80 over 127.0.0.1
B.Arduino Uno runs a simple sketch which ignore http headers and reply back only String between "GET /?<String>HTTP"
C.Javascript explained inside arduino.js 


Step1:
Reffer arduino script inside header of parent html
<head>
<script src="arduino/arduino.js"></script>
...
</head> 


Step2:
Create response element and iframe in body of parent html
<body>
...
<img id="ArduinoResponse" onclick="ArduinoSend('Data=abc12;2323sd;232;32',5);" width="44" height="44" src="arduino/ArduinoWhite.png">
<iframe style="width:0; height:0; border:0; border:none" id="ArduinoFrame" src=""></iframe>
...
</body>


Step3:
Launch bellow function using javascript (timeout 1 sec)
<script>
...
ArduinoSend('Data=' + 'Your variables here',1);
...
</script>
  